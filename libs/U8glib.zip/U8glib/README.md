U8glib-SH1106_12864-Mod
=======================

mod for the sh1106 to driver 12863 oled screen

最初动机是用于惠特的128x64的硬件IIC的一个修改模块...

## 致谢
* 小林(=leehunter8801)是最早进行修改的
:http://www.14blog.com/archives/1423
* leehunter8801非常热情的出售者,总是很有精力,还有个会发光的键盘,据说大学时代就跟着他到现在每天坐的办公室了,简而言之他是这个惠特的出售者制造者.

## 森亮号见识页面
http://see.sl088.com/id/4de
